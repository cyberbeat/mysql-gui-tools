----------
UPDATE "mysql"."db" SET "db"."name"='new'
----------

----------
UPDATE "mysql"."db" SET "db"."name"='a' WHERE "db"."host"='b'
----------

----------
UPDATE "table with space" SET "table with space"."name"='a' WHERE "table with space"."host"='b'
----------

----------
UPDATE "`" SET "`"."name"='a' WHERE "`"."host"='b'
----------

----------
UPDATE "'" SET "'"."name"='a' WHERE "'"."host"='b'
----------

----------
UPDATE "'" SET "'"."name"='a' WHERE "'"."host"='b'
----------
