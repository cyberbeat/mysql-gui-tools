----------
SELECT host, db, user     FROM mysql.db
union
SELECT host, db, _utf8'*' FROM mysql.host
----------

----------
(SELECT host, db, user     FROM mysql.db)
union
(SELECT host, db, _utf8'*' FROM mysql.host)
----------

----------
(SELECT host, db, user     FROM mysql.db)
union
(SELECT host, db, _utf8'*' FROM mysql.host)
order by 1
----------

----------
(SELECT host, db, user     FROM mysql.db)
union
(SELECT host, db, _utf8'*' FROM mysql.host)
----------

----------
SELECT host, db, 'user FROM mysql.db union SELECT host, db, _utf8\'*\'' FROM mysql.host
----------

----------
show tables
----------

----------
set @a= 1
----------


