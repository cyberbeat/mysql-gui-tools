----------
UPDATE mysql.db SET db.name='new'
----------

----------
UPDATE mysql.db SET db.name='a' WHERE db.host='b'
----------
