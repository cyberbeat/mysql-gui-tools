----------
select * from t1, t2 
where a=10;
----------

----------
select * from mysql.user
----------

----------
select distinct * from mysql.user
----------

----------
select user, host, password from mysql.user
----------

----------
select distinct user, host, password from mysql.user
----------

----------
select distinct user, host, password from mysql.user group by user
----------

