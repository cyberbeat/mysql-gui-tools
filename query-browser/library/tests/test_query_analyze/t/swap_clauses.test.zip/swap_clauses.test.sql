----------
SELECT Name FROM Country LIMIT 3 ORDER BY Name
----------
