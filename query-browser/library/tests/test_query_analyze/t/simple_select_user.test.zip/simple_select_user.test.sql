------
select 1, User, Host
from mysql.user
where User='root'
group by Host
order by Host;
------
