----------
select /* test comment */ * 
from /* xx */t1/* yy */, /* cc */t2/* dd */ -- test comment returns
where a=10  # test comment forever
----------

----------
select /* test comment */ * 
from t1 -- test comment returns
where a=10  # test comment forever
----------


----------
# Connection: dba on faster
# Host: faster
# Saved: 2004-09-16 22:02:16
#
select 1
----------
