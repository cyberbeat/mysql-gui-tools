----------
select Continent, sum(Population), min(Population),
max(Population),
std(Population),variance(Population),
group_concat(name) from Country
group by Continent;
----------

