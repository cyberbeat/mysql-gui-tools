----------
select * from t1, t2 
where a=10;
----------

